// Set the name of the root project
rootProject.name = "urlshortener"

// Include the specified subprojects in the build
include("core", "delivery", "repositories", "app")
