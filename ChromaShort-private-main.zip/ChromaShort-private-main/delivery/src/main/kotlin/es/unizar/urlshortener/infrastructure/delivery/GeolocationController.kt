package es.unizar.urlshortener.infrastructure.delivery

import es.unizar.urlshortener.core.usecases.GeolocationUseCase
import es.unizar.urlshortener.core.usecases.Geolocation
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.client.RestClientException

/**
 * Controller responsible for handling geolocation requests.
 */
@RestController
class GeolocationController(
    private val geolocationUseCase: GeolocationUseCase
) {

    /**
     * Endpoint that returns geolocation data for a given IP.
     */
    @GetMapping("/api/geolocation")
    fun getGeolocation(@RequestParam("ip") ip: String): ResponseEntity<Any> {
        return try {
            val geolocation = geolocationUseCase.getGeolocation(ip)
            ResponseEntity.ok(geolocation)
        } catch (ex: IllegalArgumentException) {
            ResponseEntity
                .badRequest()
                .body(mapOf("error" to ex.message))
        } catch (ex: RestClientException) {
            ResponseEntity
                .status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(mapOf("error" to "Failed to fetch geolocation data: ${ex.message}"))
        }
    }
}
